import java.util.Locale;

public class locale {
    public static void main(String[] args) {
        Locale l = Locale.getDefault();
        System.out.println(l);
        System.out.println(l.getCountry());
        System.out.println(l.getDisplayLanguage());
        System.out.println(l.getDisplayCountry());
    }
}
