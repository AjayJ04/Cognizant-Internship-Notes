package OOPs;
class Area{
    double findarea(int a){
        return a*a;
    }

    double findarea(int a,int b){
        return a*b;
    }
}

public class calAreaaaa {
    public static void main(String[] args) {
        Area ar = new Area();
        
        System.out.println("Area: "+ar.findarea(24));
        System.out.println("Area 2: "+ar.findarea(12, 013));
    }
}
