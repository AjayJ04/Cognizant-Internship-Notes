package OOPs;

class shape{
    void draw(){
        System.out.println("Drawing Shape");
    }
}

class circle extends shape{
    void draw(){
        System.out.println("Drawing Circel");
    }
}

public class polymorphism{
    public static void main(String[] args){
        shape c=new circle();
        c.draw();
    }
}