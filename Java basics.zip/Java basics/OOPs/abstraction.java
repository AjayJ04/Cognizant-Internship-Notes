package OOPs;

abstract class Vehicle {
    abstract void start();
}

class bike extends Vehicle{
    void start(){
        System.out.println("Bike starts with kick");
    }
}

public class abstraction {
    public static void main(String[] args) {
        Vehicle v=new bike();
        v.start();
    }
}
