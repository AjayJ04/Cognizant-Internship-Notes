package OOPs;

class bankAccount{
    private double balance;
    public void setbalance(double amount){
        balance=amount;
    }
    public double getbalance(){
        return balance;
    }

}

public class encapsulation {
    public static void main(String[] args) {
        bankAccount b=new bankAccount();
        b.setbalance(10000);
        System.out.println("Balance is "+b.getbalance());
    }
}
