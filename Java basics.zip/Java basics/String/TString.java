import java.lang.*;
public class TString{
    public static void main(String[] args){
        String s1="java";
        String s2="java";
        String s3=new String("java");
        System.out.println(s1==s2);
        System.out.println(s1==s3);
        System.out.println(s1.equals(s2));
        System.out.println(s1.equals(s3));
        System.out.println(s1.length());
        System.out.println(s1.charAt(3));
        System.out.println(s1.toUpperCase());
        String s4="Programming";
        System.out.println(s1.concat(s4));
        System.out.println(s4.substring(3));
        
    }
}