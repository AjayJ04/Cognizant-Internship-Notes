import java.util.StringTokenizer;

public class TestToken {
    public static void main(String[] args) {
        StringTokenizer s=new StringTokenizer("My name is Ajay Jadhav");
        System.out.println(s.countTokens());
        while(s.hasMoreTokens())
            System.out.println(s.nextToken());

        //using split()
        String s1="My name is Ajay Jadhav";
        String[] s2=s1.split(" ");
        for(String str:s2)
            System.out.println(str);
    }
}
