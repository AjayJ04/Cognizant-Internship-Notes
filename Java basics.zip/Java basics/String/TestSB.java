public class TestSB {
    public static void main(String[] args) {
        StringBuffer sb=new StringBuffer("Java");
        System.out.println(sb);
        sb.append(" Language");
        System.out.println(sb);
        sb.insert(4," is a ");
        System.out.println(sb);
        sb.replace(0,4,"python");
        System.out.println(sb);
        sb.delete(0,6);
        System.out.println(sb);
        sb.insert(0,"Java");
        System.out.println(sb);
        sb.reverse();
        System.out.println(sb);
        

    }
}
