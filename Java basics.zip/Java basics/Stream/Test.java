package Stream;
import java.util.*;

public class Test {
    public static void main(String[] args) {
        List<Integer> num=Arrays.asList(1,2,3,4,5);
        int sum=num.stream().reduce(0,(a,b)->a+b );
        System.out.println("Sum: "+sum);
    }
}
