package Stream;
import java.util.*;
import java.util.stream.Stream;

public class Testing {
    public static void main(String[] args){

        //Create Streams in Java using Stream.of()
        Stream<Integer> st=Stream.of(1,2,3,4,5);
        st.forEach(System.out::println);

        String[] names={"Ajay","Harsh","Arya"};
        Stream st1=Stream.of(names);
        st1.forEach(System.out::println);
    }
}
