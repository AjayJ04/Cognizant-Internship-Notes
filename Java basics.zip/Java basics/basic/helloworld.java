public class helloworld{
    public static void main(TString[] args){
        System.out.println("Hello World!");
    }
}