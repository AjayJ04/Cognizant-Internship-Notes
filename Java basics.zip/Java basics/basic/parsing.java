public class parsing {
    public static void main(String[] args) {
        String str="1000";
        int num=Integer.parseInt(str);//string to num
        System.out.println(num);
        System.out.println(str);
        String s=Integer.toString(num);  //num to string
        System.out.println(s);
        String s1=String.valueOf(num); //num to string
        System.out.println(s1);
    }
}
