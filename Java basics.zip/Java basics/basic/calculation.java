class calculate{
    void add(int a,int b){
        System.out.println("addition is "+(a+b));
    }
    void sub(int a,int b){
        System.out.println("subtraction is "+(a-b));
    }
    void mul(int a,int b){
        System.out.println("multiplication is "+(a*b));
    }
    void div(int a,int b){
        System.out.println("division is "+(a/b));
    }
}

public class calculation{
    public static void main(TString[] args) {
        calculate c=new calculate();
        c.add(5,15);
        c.sub(15, 05);
        c.mul(10, 5);
        c.div(40, 5);
    }
}