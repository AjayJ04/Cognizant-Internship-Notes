
class car{
    String color;
    int speed;
    void drive(){
        System.out.println("Car is driving");
    }
}

public class carfunction {
    public static void main(TString[] args) {
        car c=new car();
        c.color="Red";
        c.speed=100;
        c.drive();
        System.out.println("car's color is "+c.color+" and speed is "+c.speed);
    }
}


