import java.util.*;

public class listc{
    public static void main(String[] args){
        Collection<String> list=new ArrayList<>();
        list.add("Ajay");
        list.add("Harsh");
        list.add("Rishi");
        for(String name:list)
            System.out.println(name);

        Iterator<String> it=list.iterator();
        while(it.hasNext())
            System.out.println(it.next());
    }
}