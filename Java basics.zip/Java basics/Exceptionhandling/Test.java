import java.io.FileReader;
import java.io.*;
public class Test{
    static void validate(int n){
        if(n<18)
            throw new ArithmeticException("Not eligible for voting");
        System.out.println("Eligible for voting");
    }

    static void readFile() throws IOException{
        FileReader fr=new FileReader("File.txt");
    } 

    static void method1(){
        int a=10/0;
    }
    static void method2(){
        method1();
    }

    public static void main(TString[] args) {
        try {
            method2();
        } catch (ArithmeticException e) {
            System.out.println("Exception handled in main()");
        }
        
        // validate(17);
        // try {
        //     readFile();
        // } catch (IOException e) {
        //     // TODO: handle exception
        //     System.out.println("File not found");
        // }
    }
}