
class InvalidAgeException extends Exception{
    InvalidAgeException(String msg){
        super(msg);
    }
}

public class CustomE{
    static void checkage(int n) throws InvalidAgeException{
        if(n<18)
            throw new InvalidAgeException("Age is less than 18");
        else
            System.out.println("Valid age");
    }
    public static void main(TString[] args) {
        try {
            checkage(17);
        } catch (InvalidAgeException e) {
            System.out.println(e.getMessage());
        }
    }
}