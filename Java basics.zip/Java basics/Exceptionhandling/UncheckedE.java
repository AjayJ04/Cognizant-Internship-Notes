public class UncheckedE{
    public static void main(String [] args){
        String str=null;
        try{
            System.out.println(str.length());
        }catch(NullPointerException e){
            System.out.println("Caught NullPointerException: "+e.getMessage());
        }finally{
            System.out.println("Case 1 is executed");
        }

        int[] arr={1,2,3};
        try{
            System.out.println(arr[4]);
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Caught ArrayIndexOutOfBoudsException : "+e.getMessage());
        }finally{
            System.out.println("Case 2 is executed");
        }
        
    }
}