import java.io.File;
import java.io.FileReader;
import java.io.IOException;


public class checkedE {
    public static void main(TString[] args) {
        try{
            File f=new File("example.txt");
            FileReader fr=new FileReader(f);
            System.out.println("File opneed successfully");
            fr.close();
        }catch(IOException e){
            System.out.println("An IOException occured: "+e.getMessage());
        }
    }
}
