package Lambda;

interface test {
    void show(int x);   
}

interface addition{
    int add(int a,int b);
}

public class Mylambda{
    public static void main(String[] args) {
        test obj=(x)->System.out.println(x);
        obj.show(299);

        addition a=(x,y)->x+y;
        System.out.println(a.add(15,50 ));
    }
}