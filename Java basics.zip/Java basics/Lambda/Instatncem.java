package Lambda;

class Printer {
    void print(String msg) {
        System.out.println(msg);
    }
}

interface Print {
    void display(String msg);
}

//Reference to an Instance Method

public class Instatncem {
    public static void main(String[] args) {
        Printer p = new Printer();
        Print pr = p::print;
        pr.display("Hello Method Reference");
    }

}
