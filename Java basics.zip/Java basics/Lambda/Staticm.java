package Lambda;

class MathUtils {
    static int add(int a, int b) {
        return a + b;
    }
}

interface Operation {
    int operate(int a, int b);
}

//Reference to a Static Method
public class Staticm {
    public static void main(String[] args) {
        Operation op = MathUtils::add;
        System.out.println(op.operate(10, 20));
    }
}
