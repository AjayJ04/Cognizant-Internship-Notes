package Lambda;

class Employee {
    Employee() {
        System.out.println("Employee created");
    }
}

interface EmployeeFactory {
    Employee getEmployee();
}

public class Constr {
    public static void main(String[] args) {
        EmployeeFactory factory = Employee::new;
        factory.getEmployee();
    }

}
