package ResourceBundle;

import java.util.ResourceBundle;
public class RB{
    public static void main(String[] args){
        //loading properties file
        ResourceBundle rb=ResourceBundle.getBundle("ResourceBundle.messages");
        //reading values using key
        String msg=rb.getString("greeting");
        System.out.println(msg);
    }
}