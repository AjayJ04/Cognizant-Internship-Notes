package ResourceBundle;
import java.util.Currency;
import java.util.Locale;

public class Curr {
    public static void main(String[] args) {
        //creating locale for india
        Locale Ind=new Locale("en","IN");
        //getting currency instance
        Currency cr=Currency.getInstance(Ind);
        System.out.println(cr.getCurrencyCode());
        //printing currency symbol
        System.out.println(cr.getSymbol());
    }
}
