package Scanner;
import java.util.Scanner;

public class Scan {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number:");
        int num=sc.nextInt();
        System.out.println("number is:"+num);
        System.out.println("Enter a String:");
        String str=sc.next();
        System.out.println("String is:"+str);
    }
}
