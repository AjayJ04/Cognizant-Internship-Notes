package Multithreading;

class MyThread extends Thread{
    private boolean running=true;
    private boolean paused=false;
    public void run(){
        while(running){
            synchronized(this){
                while(paused){
                    try {
                        wait();
                    } catch (Exception e) {
                        // TODO: handle exception
                        e.printStackTrace();
                    }
                }
            }
            System.out.println("Thread is running...");
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }
        }
        System.out.println("Thread stopped.");
    }
    public synchronized void pauseThread(){
        paused=true;
    }
    public synchronized void resumeThread(){
        paused=false;
        notify();
    }
    public void stopThread(){
        running=false;
    }
}



public class Main {
    public static void main(String[] args) throws Exception {
        MyThread t=new MyThread();
        t.start();

        Thread.sleep(3000);
        t.pauseThread();
        System.out.println("Thread paused");

        Thread.sleep(3000);
        t.resumeThread();
        System.out.println("Thread resumed");

        Thread.sleep(3000);
        t.stopThread();
        System.out.println("Thread stopped");
    }
    
}