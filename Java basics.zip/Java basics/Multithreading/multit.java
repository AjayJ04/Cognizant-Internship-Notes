package Multithreading;
class mytask extends Thread{
    public void run(){
        for(int i=0;i<5;i++)
            System.out.println(Thread.currentThread().getName()+" is working: "+i);
    }
}

public class multit{
    public static void main(String[] args) {
        mytask t1=new mytask();
        mytask t2=new mytask();
        t1.start();
        t2.start();
    }
}