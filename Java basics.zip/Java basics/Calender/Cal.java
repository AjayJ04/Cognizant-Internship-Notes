import java.util.*;

public class Cal{
    public static void main(String[] args){
        Calendar c=Calendar.getInstance();
        System.out.println(c);
        
        int year  = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day   = c.get(Calendar.DATE);
        System.out.println(day + "-" + (month + 1) + "-" + year);
        int hour   = c.get(Calendar.HOUR);
        int minute = c.get(Calendar.MINUTE);
        int second = c.get(Calendar.SECOND);
        System.out.println(hour + ":" + minute + ":" + second);
        Date d = c.getTime();
        System.out.println(d);


    }
}