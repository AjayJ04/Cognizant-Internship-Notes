package File;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
public class Test {
    public static void main(String[] args) throws Exception {
        File f=new File("demo1.txt");
        // if(f.exists()){
        //     System.out.println("File Exist");
        //     System.out.println("Path: "+f.getAbsolutePath());
        //     System.out.println("Size:"+f.length());
        // }
        // else{
        //         f.createNewFile();
        //         System.out.println("File is created");
        // }
        FileWriter fw=new FileWriter(f);
        fw.write("Hello, I am Ajay Jadhav. I am intern at Cognizant.");
        fw.close();
        System.out.println("Data is written");

        FileReader fr=new FileReader(f);
        int ch;
        while((ch=fr.read())!=-1)
            System.out.print((char)ch);
        fr.close(); 

    }
}
